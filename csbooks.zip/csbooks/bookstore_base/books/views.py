#Django Imports

from django.shortcuts import render
from django.views.generic import ListView
from .models import Book
# REST FRAMEWORK IMPORTS
from rest_framework import generics
from .serializers import BookSerializer

# Create your views here.
class BookList(ListView):
    model = Book


class ListCreateBook(generics.ListCreateAPIView):
    queryset = Book.objects.all()
    serializer_class = serializers.BookSerializer
